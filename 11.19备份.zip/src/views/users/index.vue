<template>
  <div>
    <h2>用户</h2>
  </div>
</template>

<script>
export default {
  name: 'Users'
}
</script>

<style lang="scss" scoped></style>
