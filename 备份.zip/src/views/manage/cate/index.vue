<template>
  <div class="content">
    <h2>分类管理</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

</style>
