<template>
  <div class="content">
    <!-- <h2>Hello 新一代CMS管理系统 </h2> -->

    <!-- 可视化图表 -->
    <el-row class="chart" type="flex" justify="space-between">
      <el-col :span="6" class="visits">
        <h3>今日访问量</h3>
        <visits />
      </el-col>

      <el-col :span="6">222</el-col>
      <el-col :span="6">333</el-col>
      <el-col :span="6">444</el-col>
    </el-row>

    <!-- <el-button class="toolbar" type="primary" size="mini" icon="el-icon-s-fold" circle /> -->
  </div>
</template>

<script>
import visits from './LineChart'
export default {
  name: 'Home',
  components: {
    visits
  }
}
</script>

<style lang="scss" scoped>
.content {
  position: absolute;
  width: 100%;
  height: 100%;
  padding: 50px;
  background-color: #f9f9f9;
}
.chart {
  h3 {
    margin: 0;
  }
  .el-col {
    width: 24.1%;
    height: 250px;
    border-radius: 3px;
    background-color: #fff;
    box-shadow: 0 1px 4px rgb(0 21 41 / 8%);
  }
  .visits {
    h3 {
      position: relative;
      top: 30px;
      left: 30px;
    }
  }
}
</style>
