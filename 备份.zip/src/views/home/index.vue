<template>
  <div>
    <div class="content">
      <h2>Hello 新一代CMS管理系统 </h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home'
}
</script>

<style lang="scss" scoped>
body{
  background-color: #f6f7fb;
}
</style>
