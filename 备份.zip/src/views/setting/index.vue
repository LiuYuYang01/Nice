<template>
  <div>
    <div class="content">
      <h2>系统配置</h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Material'
}
</script>

<style lang="scss" scoped></style>
