<template>
  <div>
    <h2>创作</h2>
  </div>
</template>

<script>
export default {
  name: 'Write'
}
</script>

<style lang="scss" scoped>

</style>
