<template>
  <div>
    <h2>素材</h2>
  </div>
</template>

<script>
export default {
  name: 'Material'
}
</script>

<style lang="scss" scoped></style>
