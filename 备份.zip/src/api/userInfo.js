export default {
  userInfo: [
    {
      id: 1,
      user: 'admin',
      identity: '管理员',
      nickname: 'Liu 宇阳',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: 'http://q2.qlogo.cn/headimg_dl?dst_uin=3311118881&spec=100',
      state: false,
      date: '2022-10-19-16:30'
    },
    {
      id: 2,
      user: '13777777777',
      identity: '作者',
      nickname: '我爱学习',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: 'http://q2.qlogo.cn/headimg_dl?dst_uin=2500798479&spec=100',
      state: true,
      date: '2022-10-19-16:30'
    },
    {
      id: 3,
      user: '17788888888',
      identity: '用户',
      nickname: '知识改变命运',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: '',
      state: false,
      date: '2022-10-19-16:30'
    },
    {
      id: 4,
      user: '19755555555',
      identity: '用户',
      nickname: '学无止境',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: 'http://q2.qlogo.cn/headimg_dl?dst_uin=792734338&spec=100',
      state: true,
      date: '2022-10-19-16:30'
    },
    {
      id: 5,
      user: '15555555555',
      identity: '用户',
      nickname: '学习使我快乐',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: 'http://q2.qlogo.cn/headimg_dl?dst_uin=2622259725&spec=100',
      state: false,
      date: '2022-10-19-16:30'
    },
    {
      id: 6,
      user: '13777777777',
      identity: '作者',
      nickname: '我爱学习',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: 'http://q2.qlogo.cn/headimg_dl?dst_uin=2500798479&spec=100',
      state: true,
      date: '2022-10-19-16:30'
    },
    {
      id: 7,
      user: '17788888888',
      identity: '用户',
      nickname: '知识改变命运',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: '',
      state: false,
      date: '2022-10-19-16:30'
    },
    {
      id: 8,
      user: '19755555555',
      identity: '用户',
      nickname: '学无止境',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: 'http://q2.qlogo.cn/headimg_dl?dst_uin=792734338&spec=100',
      state: true,
      date: '2022-10-19-16:30'
    },
    {
      id: 9,
      user: '15555555555',
      identity: '用户',
      nickname: '学习使我快乐',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: 'http://q2.qlogo.cn/headimg_dl?dst_uin=2622259725&spec=100',
      state: false,
      date: '2022-10-19-16:30'
    },
    {
      id: 10,
      user: '19755555555',
      identity: '用户',
      nickname: '学无止境',
      mailbox: 'liuyuyang1o24@163.com',
      avatar: '',
      state: true,
      date: '2022-10-19-16:30'
    }
  ]
}

